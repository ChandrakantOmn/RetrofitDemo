package com.c.kotlinconcept.retrofit


data class Users(
    var address: String?="", // Gurgaon 12345
    var email: String?="", // gautam123456@gmail.com
    var mobile: String?="", // 9540468437
    var password: String?="", // 123456
    var username: String?="" // GautamCodes
)